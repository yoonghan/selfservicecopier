function test(){
    var a = "a" +
    "b" +
    "c";
}
